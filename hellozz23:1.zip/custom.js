$(document).ready(function($){

    
//----  Our mep area ----//    
    var myCenter=new google.maps.LatLng(23.77080, 90.40910);

            function initialize(){
	           	var mapProp = {
	              center:myCenter,
	              zoom:15,
	              scrollwheel: false,
	              mapTpeIdy:google.maps.MapTypeId.TERRAIN,
                    styles: [
    {
        "featureType": "all",
        "elementType": "all",
        "stylers": [
            {
                "visibility": "on"
            }
        ]
    },
    {
        "featureType": "administrative.country",
        "elementType": "geometry.fill",
        "stylers": [
            {
                "visibility": "on"
            }
        ]
    },
    {
        "featureType": "poi.business",
        "elementType": "all",
        "stylers": [
            {
                "visibility": "on"
            }
        ]
    }
]
	              };

	            var map=new google.maps.Map(document.getElementById("google-map"),mapProp);

	            var marker=new google.maps.Marker({
	              position:myCenter,
	              animation:google.maps.Animation.BOUNCE,
	              icon:'img/map/map-icon-blue.png' 
            });
            

            marker.setMap(map);
            }

            google.maps.event.addDomListener(window, 'load', initialize); 
    
    //---end map area---//

    
});
//--our-carousel-area--//
$('.client-carousel').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    navText:['<i class="fa fa-chevron-left" aria-hidden="true"></i>','<i class="fa fa-chevron-right" aria-hidden="true"></i>'],
    items:4,
    dots:true
   
});
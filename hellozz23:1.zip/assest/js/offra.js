(function($) {
    "use strict";


        
    $('.menu_toggle').on('click',function(){
        $(this).siblings('.navbar-mobile').toggleClass('active');
    });

var myMenu = $('.navbar-nav > li');
        myMenu.children('ul').addClass('DropDown');
        var dropDown = $('.DropDown');
        var dropDownMenu = $('.DropDown').children('li');
        $('.DropDown').children('li').children('ul').addClass('subMenu');
        $('.subMenu').children('li').children('ul').addClass('NsubMenu');
        var subMenu = $('.subMenu');
            $('.DropDown').parent('li').addClass('DpSign');
            $('.subMenu').parent('li').addClass('DpSign');
            $('.NsubMenu').parent('li').addClass('DpSign');
        myMenu.on('click',function(ev){
            ev.preventDefault();
            $(this).children('.DropDown').slideToggle();
            $(this).siblings('li').children('.DropDown').slideUp();
            $('.subMenu').slideUp();
            $('.subMenu li ul').slideUp();
        });
        dropDownMenu.on('click',function(ev){
            ev.preventDefault();
            $(this).children('ul').slideToggle();
            ev.stopPropagation();
        });
        $('.subMenu li').on('click',function(ev){
            ev.preventDefault();
            $(this).children('ul').slideToggle();
            ev.stopPropagation();
        })


    $(document).mouseup(function (e) {
        var container = $(".navbar-nav,.DropDown,.subMenu,.NsubMenu,.modal-content");
        if (!container.is(e.target) && container.has(e.target).length === 0) {
            $('.DropDown').slideUp();
            $('.subMenu').slideUp();
            $(".NsubMenu").slideUp();
            $('.modal').removeClass('active');
            $('.modal').fadeOut();
//            $('html, body').css('overflowY', 'auto');

        }

    });
var clicker = $('.tab-menu a');
        var atr = $('.tab-content').attr('id');
        var wrapper = $('.tabe-container');
        $('.tab-content').addClass('nodisplay')
        var allTabs = wrapper.find('div');
        var hoverable = $('.tab-menu.hoverable a');

        clicker.click(function (event) {
            event.preventDefault();
            $(this).parent().addClass('active');
            $(this).parent().siblings().removeClass('active');
            var result = $(this).attr('href');
            var newValue = result.replace('#', '');
            var shower = $('.tab-content[id*=' + newValue + ']').addClass('active');
            shower.siblings().removeClass('active');
        });

        if ($('.tab-menu').hasClass('hoverable')) {
            hoverable.on('mouseenter', function (event) {
                event.preventDefault();
                $(this).parent().addClass('active');
                $(this).parent().siblings().removeClass('active');
                var result = $(this).attr('href');
                var newValue = result.replace('#', '');
                var shower = $('.tab-content[id*=' + newValue + ']').addClass('active');
                shower.siblings().removeClass('active');
            });
        }
    var toggleParent = $('.toggle-nav').children().find('ul').parent().addClass('down-sign');
    $('.toggle-nav').children().find('ul').slideUp();
    $('.toggle-nav').children('li').on('click',function(event){
        event.preventDefault();
        $(this).addClass('active');
        $(this).children('ul').slideToggle();
        $(this).siblings('li').children('ul').slideUp();
        $(this).siblings('li').removeClass('active');
    });
    
    $('.modal').fadeOut();
    var dModal = $('.modal');
    var Cmodal = document.getElementById('modal');
    var dModalcont = $('.modal-content');
       $('[data-modal-name]').on('click',function (event) {
            event.preventDefault();
            $(this).addClass('myModal');
            var current = ($(this).attr('data-modal-name'));
           console.log(current);
            var findModal = $(document).find("[data-target-modal='" + current + "']").fadeIn();
           
            $('.modal').addClass('active');
           if ($(".modal.active")[0]){
                $('html, body').css('overflowY', 'hidden');
            } 
        });
       $('.modal-cancel').on('click', function () {
            $('.modal').removeClass('active');
            $('.modal').fadeOut();
           $('html, body').css('overflowY', 'auto');
        });
//        $(window).click = function(event) {
//            
//
//            if (event.target == dModal) {
//                //dModal.style.display = "none";
//                console.log('outer modal');
//            }
//            if (event.target == dModalcont) {
//                //dModal.style.display = "none";
//                console.log('inner modal');
//            }
//        }
        $('.modal').on('click',function(){
            $('html, body').css('overflowY', 'auto');
        });
    
    $('.alert-cancel').on('click',function(){
        $(this).parent('.alert').hide();
    });
        
    //This code for collapse and Accordion    
    $('[data-collapse-panel]').hide();
    var acParent = $('.single-accordion');
    var showAc = $('.single-accordion.show');
        $('[data-collapse]').on('click',function (event) {
        event.preventDefault();
        var AcCurrent = ($(this).attr('href'));
        var acNew = AcCurrent.replace('#', '');
        $(this).parent('.single-accordion').toggleClass('show');
        var findAccordion = $(document).find("[id='" + acNew + "']").slideToggle();
        $(this).parent('.single-accordion').siblings().children('[data-collapse-panel]').slideUp();
        $(this).parent('.single-accordion').siblings().removeClass('show');
    });
    if($('.single-accordion').hasClass('show')){
       showAc.find('[data-collapse-panel]').slideDown();
    }
    
    
    $('[data-name]').on('click',function (event) {
        event.preventDefault();
        var AcCurrent = ($(this).attr('href'));
        var acNew = AcCurrent.replace('#', '');

        setTimeout(function(){
           $('body').toggleClass('off-show');
       }, 10);    
        var findAccordion = $(document).find("[id='" + acNew + "']").toggleClass('show');
        if($('.offcanvas.show').hasClass('offcanvas-push')){
            $('body').toggleClass('offcanvas-push');
        }

    });
    $('.offcanvas-cancel').on('click',function(){
        $(this).parent('.offcanvas').removeClass('show');
        $('body').removeClass('off-show');
        $('body').removeClass('offcanvas-push');
    });
    
    /*tooltip*/
    
     $('.tooltiptext').hide();
    $('.tooltip').on('mouseenter',function(){
        var string =this.innerHTML;
        var position = this.dataset.tooltipposition;
        var text= this.dataset.tooltiptext;
        string+='<span class="tooltiptext tooltiptext_'+position+'"><span class="text">'+text+'</span></span>';
        this.classList.add('tooltip_'+position);
        this.innerHTML=string;
        $(this).children('.tooltiptext').show(100);
    }).on('mouseleave',function(){
        $(this).children('.tooltiptext').hide();
        $(this).children('.tooltiptext').remove();
        var position = this.dataset.tooltipposition;
        this.classList.remove('tooltip_'+position);
    });
    
    /*riffle*/
    
    		$(".riffle-effect").click(function (e) {
  
  // Remove any old one
  $(".ripple").remove();

  // Setup
  var posX = $(this).offset().left,
      posY = $(this).offset().top,
      buttonWidth = $(this).width(),
      buttonHeight =  $(this).height();
  
  // Add the element
  $(this).prepend("<span class='ripple'></span>");
  console.log(this);

  
 // Make it round!
  if(buttonWidth >= buttonHeight) {
    buttonHeight = buttonWidth;
  } else {
    buttonWidth = buttonHeight; 
  }


  
  // Get the center of the element
  var x = (e.pageX - posX - buttonWidth / 2)+this.offsetLeft;
  var y = e.pageY - posY - buttonHeight / 2+this.offsetTop;
  
 
  // Add the ripples CSS and start the animation
  $(".ripple").css({
    width: buttonWidth,
    height: buttonHeight,
    top: (y + 10) + 'px',
    left: (x + 10) + 'px'
  }).addClass("rippleEffect");
});

    
 })(jQuery);